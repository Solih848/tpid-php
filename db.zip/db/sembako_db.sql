-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jun 2024 pada 03.47
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sembako_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username1` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin_super') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username1`, `password`, `role`) VALUES
(1, 'solihudin848@gmail.com', '45', 'admin_super');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `nama_pasar` varchar(100) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `foto_produk` varchar(255) DEFAULT NULL,
  `operator` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `nama_barang`, `nama_pasar`, `harga`, `tanggal`, `foto_produk`, `operator`) VALUES
(100, 'Minyak Goreng', 'Pasar A', 34000.00, '2024-03-28', 'minyak.png', ''),
(101, 'Gula', 'Pasar A', 56000.00, '2024-03-28', 'gula.png', ''),
(102, 'Minyak Goreng', 'Pasar A', 50000.00, '2024-03-18', 'minyak.png', ''),
(103, 'Beras', 'Pasar B', 67000.00, '2024-03-18', 'beras.png', ''),
(104, 'Gula', 'Pasar B', 60000.00, '2024-03-18', 'gula.png', ''),
(105, 'Minyak Goreng', 'Pasar B', 47000.00, '2024-03-18', 'minyak.png', ''),
(108, 'Minyak Goreng', 'Pasar B', 67.00, '2024-03-22', 'minyak.png', 'iron'),
(109, 'Minyak Goreng', 'Pasar A', 78.00, '2024-03-22', 'minyak.png', 'solih'),
(110, 'Minyak Goreng', 'Pasar A', 78888.00, '2024-03-30', 'minyak.png', 'iron'),
(111, 'Gula', 'Pasar A', 9000.00, '2024-03-31', 'gula.png', 'solih');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_inflasi`
--

CREATE TABLE `data_inflasi` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `inflasi` decimal(10,2) DEFAULT NULL,
  `inflasi_tahun_kalender` decimal(10,2) DEFAULT NULL,
  `inflasi_tahun_ke_tahun` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `data_inflasi`
--

INSERT INTO `data_inflasi` (`id`, `tanggal`, `inflasi`, `inflasi_tahun_kalender`, `inflasi_tahun_ke_tahun`) VALUES
(10, '2024-04-05', 0.05, 0.02, 0.03);

-- --------------------------------------------------------

--
-- Struktur dari tabel `inflasi`
--

CREATE TABLE `inflasi` (
  `id` int(11) NOT NULL,
  `username2` varchar(100) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `opd` varchar(100) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `inflasi`
--

INSERT INTO `inflasi` (`id`, `username2`, `nip`, `jabatan`, `opd`, `whatsapp`, `email`, `password`) VALUES
(17, 'kuta', '4560', 'io', 'tyop', '098455666', 'iort@gmail.com', '11'),
(19, 'aji', '36', '3', '3', '3', 'k@gmail.com', '234');

-- --------------------------------------------------------

--
-- Struktur dari tabel `operator`
--

CREATE TABLE `operator` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `opd` varchar(100) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `operator`
--

INSERT INTO `operator` (`id`, `username`, `nip`, `jabatan`, `opd`, `whatsapp`, `email`, `password`) VALUES
(14, 'Iron', '666666666', 'Komando Militer', 'uuuuuu', '0987653', 'solihudin848@gmail.com', '44'),
(15, 'Solih', '1235678990', 'Kepala', 'kamu', '087576554990', 'ayugokil88@gmail.com', '00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sub_judul_produk`
--

CREATE TABLE `sub_judul_produk` (
  `id` int(11) NOT NULL,
  `judul_produk` varchar(255) NOT NULL,
  `nama_bahan_pokok` varchar(255) DEFAULT NULL,
  `satuan` varchar(50) DEFAULT NULL,
  `harga_kemarin` int(11) DEFAULT NULL,
  `harga_sekarang` int(11) DEFAULT NULL,
  `perubahan_rp` int(255) DEFAULT NULL,
  `perubahan_persen` decimal(5,2) DEFAULT NULL,
  `nama_pasar` varchar(100) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `operator_pasar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `sub_judul_produk`
--

INSERT INTO `sub_judul_produk` (`id`, `judul_produk`, `nama_bahan_pokok`, `satuan`, `harga_kemarin`, `harga_sekarang`, `perubahan_rp`, `perubahan_persen`, `nama_pasar`, `tanggal`, `operator_pasar`) VALUES
(68, 'Kopi', 'Top Kopi', 'Gram', 20000, 90000, NULL, NULL, 'Lenteng', '2024-03-26', 'solih'),
(70, 'Minyak Goreng', 'Bimoli', 'Liter', 20000, 37000, NULL, NULL, 'Pasar Pahlawan', '2024-03-08', 'iron'),
(72, 'Semen', 'Semen Gresik', 'Kg', 25000, 90000, NULL, NULL, 'Pasar Pahlawan', '2024-03-23', 'abu'),
(73, 'Semen', 'Semen Holsim', 'Kg', 25000, 90000, NULL, NULL, 'Anom', '2024-03-01', 'abu'),
(74, 'Beras', 'Beras Medium', 'Kg', 0, 90000, NULL, NULL, 'Lenteng', '2024-03-28', 'abu'),
(75, 'Beras', 'Beras Bulog', 'Kg', 20000, 70000, NULL, NULL, 'Lenteng', '2024-03-26', 'iron'),
(77, 'Beras', 'Pisang Aroma', 'Gram', 30000, 37000, NULL, NULL, 'Pasar Pahlawan', '2024-03-08', 'iron'),
(78, 'Daging', 'Ajem', 'Kg', 300000, 30000, NULL, NULL, 'Lenteng', '2024-03-26', 'iron'),
(87, 'Beras', 'Pisang Aroma', 'Kg', 30000, 20000, NULL, NULL, 'Lenteng', '2024-03-13', 'iron '),
(89, 'Daging', 'Ajem', 'Miligram', 0, 30000, NULL, NULL, 'Batang-Batang', '2024-03-01', 'iron '),
(90, 'Beras', 'Pisang Aroma', 'Kg', 30000, 37000, NULL, NULL, 'Lenteng', '2024-03-06', 'iron '),
(91, 'Daging', 'Ajem', 'Ons', 0, 90000, NULL, NULL, 'Ganding', '2024-03-19', 'iron '),
(92, 'Beras', 'Pisang Aroma', 'Kg', 30000, 90000, NULL, NULL, 'Lenteng', '2024-03-20', 'iron ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(21, 'Iron', '44', 'operator'),
(22, 'Solih', '00', 'operator'),
(24, 'kuta', '11', 'inflasi'),
(26, 'aji', '234', 'inflasi');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_inflasi`
--
ALTER TABLE `data_inflasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `inflasi`
--
ALTER TABLE `inflasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `operator`
--
ALTER TABLE `operator`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sub_judul_produk`
--
ALTER TABLE `sub_judul_produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT untuk tabel `data_inflasi`
--
ALTER TABLE `data_inflasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `inflasi`
--
ALTER TABLE `inflasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `operator`
--
ALTER TABLE `operator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `sub_judul_produk`
--
ALTER TABLE `sub_judul_produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
