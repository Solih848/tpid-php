-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jun 2024 pada 03.47
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sem`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_inflasi`
--

CREATE TABLE `data_inflasi` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `inflasi` decimal(10,2) DEFAULT NULL,
  `inflasi_tahun_kalender` decimal(10,2) DEFAULT NULL,
  `inflasi_tahun_ke_tahun` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `data_inflasi`
--

INSERT INTO `data_inflasi` (`id`, `tanggal`, `inflasi`, `inflasi_tahun_kalender`, `inflasi_tahun_ke_tahun`) VALUES
(10, '2024-08-01', 0.08, 0.07, 0.06),
(20, '2024-09-01', 0.11, 0.12, 0.13),
(21, '2024-10-01', 0.10, 0.20, 0.19);

-- --------------------------------------------------------

--
-- Struktur dari tabel `operator`
--

CREATE TABLE `operator` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `opd` varchar(100) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `operator`
--

INSERT INTO `operator` (`id`, `username`, `nip`, `jabatan`, `opd`, `whatsapp`, `email`, `password`) VALUES
(14, 'Iron', '666666666', 'Komando Militer', 'uuuuuu', '0987653', 'solihudin848@gmail.com', '89'),
(15, 'Solih', '1235678990', 'Kepala', 'kamu', '087576554990', 'ayugokil88@gmail.com', '00'),
(16, 'Abu', '897', 'operator pasar kalianget', 'iju', '098765432444', 'ayugokil88@gmail.com', '12');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sub_judul_produk`
--

CREATE TABLE `sub_judul_produk` (
  `id` int(11) NOT NULL,
  `judul_produk` varchar(255) NOT NULL,
  `nama_bahan_pokok` varchar(255) DEFAULT NULL,
  `satuan` varchar(50) DEFAULT NULL,
  `harga_kemarin` int(11) DEFAULT NULL,
  `harga_sekarang` int(11) DEFAULT NULL,
  `perubahan_rp` int(255) DEFAULT NULL,
  `perubahan_persen` decimal(5,2) DEFAULT NULL,
  `nama_pasar` varchar(100) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `operator_pasar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `sub_judul_produk`
--

INSERT INTO `sub_judul_produk` (`id`, `judul_produk`, `nama_bahan_pokok`, `satuan`, `harga_kemarin`, `harga_sekarang`, `perubahan_rp`, `perubahan_persen`, `nama_pasar`, `tanggal`, `operator_pasar`) VALUES
(104, 'Beras', 'Beras Medium', 'Liter', 0, 1000, NULL, NULL, 'Bromo', '2024-04-22', 'solih'),
(105, 'Beras', 'Beras Medium', 'Liter', 0, 2000, NULL, NULL, 'Anom', '2024-04-23', 'solih'),
(106, 'Minyak Goreng', 'Minyak Goreng Curah', 'Gram', 0, 67000, NULL, NULL, 'Anom', '2024-05-08', 'solih'),
(107, 'Minyak Goreng', 'Minyak Goreng Curah', 'Liter', 67000, 68000, NULL, NULL, 'Anom', '2024-06-10', 'iron');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(21, 'Iron', '89', 'operator'),
(22, 'Solih', '00', 'operator'),
(23, 'Abu', '12', 'operator');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_inflasi`
--
ALTER TABLE `data_inflasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `operator`
--
ALTER TABLE `operator`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sub_judul_produk`
--
ALTER TABLE `sub_judul_produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_inflasi`
--
ALTER TABLE `data_inflasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `operator`
--
ALTER TABLE `operator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `sub_judul_produk`
--
ALTER TABLE `sub_judul_produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
